#include <stdio.h>
#include <string.h>
#include "smalloc.h"

int main() {
    printf("메모리 할당 테스트 시작\n");

    // 기본 할당 테스트
    char *str1 = (char *)smalloc(20);
    if (str1) {
        strcpy(str1, "Hello, World!");
        printf("str1: %s\n", str1);
    }

    // 재할당 테스트
    str1 = (char *)srealloc(str1, 40);
    if (str1) {
        strcat(str1, " Extended!");
        printf("str1 (재할당 후): %s\n", str1);
    }

    // 메모리 해제
    sfree(str1);

    // 할당 모드 변경 테스트
    printf("\n할당 모드 테스트\n");
    sset_mode(FIRSTFIT);
    void *p1 = smalloc(100);
    void *p2 = smalloc(200);
    void *p3 = smalloc(150);

    printf("p1: %p\n", p1);
    printf("p2: %p\n", p2);
    printf("p3: %p\n", p3);

    // 메모리 해제 및 병합 테스트
    sfree(p2);  // 중간 블록 해제
    sfree(p1);  // 인접 블록 해제
    smcoalesce();  // 블록 병합

    // 병합 후 새로운 할당
    void *p4 = smalloc(250);
    printf("p4 (병합 후 할당): %p\n", p4);

    // 남은 메모리 정리
    sfree(p3);
    sfree(p4);

    printf("테스트 완료\n");
    return 0;
} 